import React from 'react';

export const AppFooter = (props) => {

    return (
        <div className="layout-footer">
            <img src="assets/layout/images/logo.png" alt="Logo" height="40" className="mr-2" />
        </div>
    );
}
