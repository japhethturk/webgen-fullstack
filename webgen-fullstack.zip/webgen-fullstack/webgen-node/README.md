# webgen

WebGen Node JS backend

# run

$ nodemon app.js


# restart

$ sudo /bin/systemctl restart apipanel.service


https://preview.colorlib.com/theme/wordify/index.html
https://preview.colorlib.com/theme/webmag/
https://preview.colorlib.com/theme/miniblog/

- video tip arama sonuclari ekleme
- olusturulmus htmli kullaniciya gosterme olsun,  domainle bagla dediginde baglansin
headerda sevgi.bilgisiburada.com seklinde kle
ic sayfa etiketi olsun
shema.org
trmalar ekle
fotografi duzenle olsun